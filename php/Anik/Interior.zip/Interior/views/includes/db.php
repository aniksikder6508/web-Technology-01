<?php 
$conn =mysqli_connect("localhost","root","","interiordesign_project");
if ($conn) {
	
}
 ?>
<?php

require_once "dbcon.php";

if(isset($_POST['submit'])){

$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$gender=$_POST['gender'];
$choice=implode(",",$_POST['choice']);






$status=$_POST['select'];
$comment=$_POST['textarea'];




mysqli_query($con,"INSERT INTO `form`(`name`,`email`,`password`,`gender`,`choice`,`status`,`comment`) VALUES('$name','$email','$password','$gender','$choice','$status','$comment')");



}
?>